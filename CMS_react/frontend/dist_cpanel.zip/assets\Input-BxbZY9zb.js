import{r as e}from"./rolldown-runtime-QTnfLwEv.js";import{Ut as t}from"./vendor_icons-BtKSRwxQ.js";import{y as n}from"./vendor_react-CaxxEfPQ.js";var r=e(t(),1),i=n(),a=(0,r.forwardRef)(({label:e,id:t,type:n=`text`,error:r,helpText:a,className:o=``,fullWidth:s=!0,...c},l)=>(0,i.jsxs)(`div`,{className:`${s?`w-full`:``} ${o}`,children:[e&&(0,i.jsx)(`label`,{htmlFor:t,className:`block text-sm font-medium text-text-primary mb-1`,children:e}),(0,i.jsx)(`div`,{className:`relative`,children:(0,i.jsx)(`input`,{ref:l,id:t,type:n,className:`
            block w-full rounded-lg border bg-white px-4 py-2.5 text-text-primary 
            transition-colors duration-200 ease-in-out
            focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary
            disabled:bg-slate-50 disabled:text-slate-500 disabled:cursor-not-allowed
            ${r?`border-danger focus:ring-danger focus:border-danger`:`border-border hover:border-slate-400`}
          `,...c})}),r&&(0,i.jsx)(`p`,{className:`mt-1.5 text-sm text-danger`,id:`${t}-error`,children:r}),a&&!r&&(0,i.jsx)(`p`,{className:`mt-1.5 text-sm text-text-secondary`,id:`${t}-help`,children:a})]}));a.displayName=`Input`;export{a as t};